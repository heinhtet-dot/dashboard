from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import *
from django.db import models

class OrderForm(forms.ModelForm):
    cus_name = forms.CharField()
    clo_type = forms.CharField()
    amount = forms.IntegerField()
    od_date = forms.DateField()
    deli_date = forms.DateField()
    address = forms.CharField()
 
    class Meta:
        model = Order
        fields =['cus_name','clo_type','amount','od_date','deli_date','address']

    def clean(self):
        cleaned_data = super(OrderForm, self).clean()
        cus_name = cleaned_data.get('cus_name')
        clo_type = cleaned_data.get('clo_type')
        amount = cleaned_data.get('amount')
        od_date = cleaned_data.get('od_date')
        deli_date = cleaned_data.get('deli_date')
        address = cleaned_data.get('address')
        if not cus_name and not clo_type and not amount and not od_date and not deli_date and not address:
            raise forms.ValidationError('You have to write something!')  


class ItemForm(forms.ModelForm):
    item_name = models.CharField(max_length=50)
    price = models.IntegerField()

    class Meta:
        model = Cloth_Item
        fields = ['item_name', 'price']

    def clean(self):
        cleaned_data = super(ItemForm, self).clean()
        item_name = cleaned_data.get('item_name')
        price = cleaned_data.get('price')
        if not item_name and not price:
            raise forms.ValidationError('You have to write something')



class StockForm(forms.ModelForm):
    item =models.CharField(max_length=50)
    qty = models.CharField(max_length=50)

    class Meta:
        model = Stock
        fields = ['item', 'qty']

    def clean(self):
        cleaned_data = super(StockForm, self).clean()
        item = cleaned_data.get('item')
        qty  = cleaned_data.get('qty')
        if not item and not qty:
            raise forms.ValidationError('You have to write something')


class SaleForm(forms.ModelForm):
    sale_item = models.CharField(max_length=100)
    sale_date= models.DateField(default= timezone.now)
    sale_qty = models.CharField(max_length=100, default='0')
    sale_price = models.IntegerField(default='0')
    sale_total = models.IntegerField(default='0')
    sale_remark= models.CharField(max_length=100)

    class Meta:
        model = Sales
        fields = [ 'sale_item','sale_date', 'sale_qty', 'sale_price', 'sale_total', 'sale_remark' ]

    def clean(self):
        cleaned_data = super(SaleForm, self).clean()
        sale_item = cleaned_data.get('sale_item')
        sale_date = cleaned_data.get('sale_date')
        sale_qty  = cleaned_data.get('sale_qty')
        sale_price= cleaned_data.get('sale_price')
        sale_remark = cleaned_data.get('sale_remark')
        if not sale_item and not sale_date and not sale_qty and not sale_price and not sale_remark:
            raise forms.ValidationError('You have to write something')
    
            
                              