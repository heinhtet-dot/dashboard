from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
class Profile(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    object = models.Manager()

    def __str__(self):
        return self.username
class Cloth_Item(models.Model):
    item_name = models.CharField(max_length=50)
    price = models.IntegerField()
    
class Order(models.Model):
    cus_name = models.CharField(max_length=50)
    cus_ph = models.IntegerField()
    cloth_type = models.CharField(max_length=100)
    amount = models.IntegerField()
    order_date = models.DateField(default= timezone.now)
    deli_date = models.DateField(default= timezone.now)
    address = models.CharField(max_length=100)
    order_status = models.CharField(max_length=100)


    #author = models.ForeignKey(User,on_delete)
    def __str__(self):
        return self.cus_name
class Stock(models.Model):
    item =models.CharField(max_length=50)
    qty = models.CharField(max_length=50)

class Sales(models.Model):
    sale_item = models.CharField(max_length=100)
    sale_date= models.DateField(default= timezone.now)
    sale_qty = models.CharField(max_length=100, default='0')
    sale_price = models.IntegerField(default='0')
    sale_total = models.IntegerField(default='0')
    sale_remark= models.CharField(max_length=100)
    