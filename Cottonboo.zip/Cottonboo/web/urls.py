from django.urls import path
from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('', views.index, name='webindex'),
    path('login', views.uslogin, name='login'),
    path('logout', views.uslogout, name='logout'),
    path('dashboard', views.dashboard, name='web-dashboard'),
#purchase
    path('purchase_order', views.purchase_order, name='web-purchase_order'),
    path('purchase_order_submission', views.purchase_order_submission, name='web-purchase_order_submission'),
    path('order_list', views.order_list, name='web-order_list'),
    path(r'^(?P<id>\d+)/edit/$', views.order_update, name='order_edit'),   
    path('delete/<int:id>/', views.order_delete, name='orderDelete'),

#instock
    path('instock', views.instock, name='web-instock'),
    path('stock_submission' , views.instock_submission, name = 'stock_submission'),
    path('stock_list', views.stock_list, name='web-stock_list'),
    path(r'^(?P<id>\d+)/stockedit/$', views.stock_update, name='stock_edit'),
    path('stockdelete/<int:id>/', views.stock_delete, name='stockDelete'),
    
#sale
    path('sale',views.sales, name='web-sale'),
    path('sale_submission',views.sales_submission,name='sales_submission'),
    path('sale_list',views.sale_list,name='sale_list'),
    path(r'^(?P<id>\d+)/saleedit/$', views.sale_update, name='sale_edit'),
    path('saledelete/<int:id>/', views.sale_delete, name='saleDelete'),
    
#Item
    path('add_item',views.add_item, name ='web-add_item'),
    path('add_item_submission', views.item_submission, name='web-add_item_submission'),
    path('item_list',views.item_list, name='web-item_list'),
    path(r'^(?P<id>\d+)/itemedit/$', views.item_update, name='item_edit'),
    path('itemdelete/<int:id>/', views.item_delete, name='itemDelete'),

   
#search  
    path('searchorder',views.searchorder,name = 'searchorder'),
    path('searchstock',views.searchstock,name = 'searchstock'),
    path('searchitem' , views.searchitem, name = 'searchitem'),
    path('searchsale' , views.searchsale, name = 'searchsale'),


]