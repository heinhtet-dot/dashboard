from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from .models import *
from django.db import models
from django.db.models import Q
from django.contrib.auth.forms import UserCreationForm 
from django.http.response import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse
from django.contrib import messages
from .forms import *
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404
from web.forms import OrderForm
from web.forms import ItemForm
from web.forms import StockForm
from web.forms import SaleForm
from django.contrib.auth.decorators import login_required


@login_required
def uslogout(request):
    logout(request)
    return HttpResponseRedirect(reverse('webindex'))

def index(request):
    return render(request,'website/index.html')

def uslogin(request):  
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = Profile(username=username, password=password)
        if user:
            return render(request, 'website/dashboard.html')
        else:
            return HttpResponse({'Your Username or Password is invalid!'})
    else:
        return render(request, 'website/index.html')
#message.success(request, f'Account created for {username}')
    
def dashboard(request):
    return render(request, 'website/dashboard.html')

def purchase_order(request):
    clotypes = Cloth_Item.objects.all()
            
    return render(request,'website/purchase_order.html',{'clotypes': clotypes})

def purchase_order_submission(request):
    cusname = request.POST.get('cusname')
    cusph = request.POST.get('cusph')
    amount = request.POST.get('amount')
    clotype = request.POST.get('clotype')
    oddate = request.POST.get('oddate')
    delidate = request.POST.get('delidate')
    address = request.POST.get('address')
    order_status = request.POST.get('order_status')
    insertorder = Order(cus_name=cusname,cus_ph=cusph,cloth_type = clotype,amount=amount,order_date=oddate,deli_date=delidate,address=address,order_status = order_status)
    insertorder.save()
    success = "Order is successfully inserted!!!"
    context = {
        'success' : success,
    }
    return render(request, 'website/dashboard.html',context)
        

def order_list(request):
    all_order = Order.objects.all().order_by('-id')
    paginator = Paginator(all_order,3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'website/order_list.html',{'page_obj' : page_obj})

#Edit order
def order_update(request, id):
    obj= get_object_or_404(Order, id=id)
    form = OrderForm(request.POST or None, instance= obj)

    if form.is_valid():
        obj= form.save(commit= False)
        obj.save()
        messages.success(request, "You successfully updated the Order!!")
        context= {'form': form}
        return render(request, 'website/dashboard.html', context)
    else:
        context= {'form': form}
        return render(request,'website/Edit.html' , context)


#Delete order
def order_delete(request, id):
    order= get_object_or_404(Order, id=id)    
    if request.method=='POST':
        order.delete()
        return redirect('web-dashboard')
    return render(request, 'website/order_list.html', {'order': order})

def add_item(request):
    return render(request, 'website/add_item.html')

def item_submission(request):
    it_name = request.POST.get('item')
    price = request.POST.get('price')
    insertitem = Cloth_Item(item_name=it_name, price=price)
    insertitem.save()
    success = "Item is successfully inserted!!!"
    return render(request, 'website/dashboard.html',{'success' : success})

def item_list(request):
    all_item = Cloth_Item.objects.all().order_by('-id')
    paginator = Paginator(all_item,3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'website/item_list.html',{'page_obj' : page_obj})

# edit item
def item_update(request, id):
    obj= get_object_or_404(Cloth_Item, id=id)
    form = ItemForm(request.POST or None, instance= obj)

    if form.is_valid():
        obj= form.save(commit= False)
        obj.save()
        messages.success(request, "You successfully updated the Item!!")
        context= {'form': form}
        return render(request, 'website/dashboard.html', context)
    else:
        context= {'form': form}
        return render(request,'website/item_edit.html' , context)

#Delete item
def item_delete(request,id):

    itemdel= get_object_or_404(Cloth_Item,id= id)
  
    if request.method=='POST':
        itemdel.delete()
        return redirect('web-dashboard')
    return render(request, 'website/item_list.html', {'Cloth_Item': itemdel})

    
def instock(request):
    return render(request, 'website/instock.html')

def instock_submission(request):
        item_name = request.POST.get('item')
        qty = request.POST.get('qty')
        insertinstock = Stock( item = item_name , qty = qty)
        insertinstock.save()
        success = "Instock is successfully inserted!!!"
        return render(request, 'website/dashboard.html',{'success' : success})

def stock_list(request):
    all_stock = Stock.objects.all().order_by('-id')
    paginator = Paginator(all_stock,3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'website/stock_list.html',{'page_obj' : page_obj})

# edit Stock
def stock_update(request, id):
    obj= get_object_or_404(Stock, id=id)
    form = StockForm(request.POST or None, instance= obj)

    if form.is_valid():
        obj= form.save(commit= False)
        obj.save()
        messages.success(request, "You successfully updated the Stock!!")
        context= {'form': form}
        return render(request, 'website/dashboard.html', context)
    else:
        context= {'form': form}
        return render(request,'website/stock_edit.html' , context)

#Delete stock
def stock_delete(request,id):
    instock= get_object_or_404(Stock,id= id)
  
    if request.method=='POST':
        instock.delete()
        return redirect('web-dashboard')
    return render(request, 'website/stock_list.html', {'Stock': instock})



def sales(request):
    return render(request, 'website/purchase_sale.html')

def sales_submission(request):
    sale_item= request.POST.get('item')
    sale_date = request.POST.get('date')
    sale_qty = request.POST.get('qty')
    sale_price = request.POST.get('price')
    sale_total = request.POST.get('total')
    sale_remark = request.POST.get('remark')
    sale_submit = Sales(sale_item = sale_item, sale_date=sale_date ,sale_qty =sale_qty,sale_price=sale_price, sale_total=sale_total,
        sale_remark=sale_remark)
    sale_submit.save()
    success = "Sales is successfully inserted!!!"
    return render(request, 'website/dashboard.html',{'success':success})


def sale_list(request):
    all_sale =Sales.objects.all().order_by('-id')
    paginator = Paginator(all_sale,3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'website/sale_list.html',{'page_obj' : page_obj})



# edit sale
def sale_update(request, id):
    obj= get_object_or_404(Sales, id=id)
    form = SaleForm(request.POST or None, instance= obj)

    if form.is_valid():
        obj= form.save(commit= False)
        obj.save()
        messages.success(request, "You successfully updated the Sale!!")
        context= {'form': form}
        return render(request, 'website/dashboard.html', context)
    else:
        context= {'form': form}
        return render(request,'website/sale_edit.html' , context)


#Delete sale
def sale_delete(request,id):
    insale= get_object_or_404(Sales,id= id)
  
    if request.method=='POST':
        insale.delete()
        return redirect('web-dashboard')
    return render(request, 'website/sale_list.html', {'Stock': insale})







def searchorder(request):
    
    if request.method== 'POST':
        search = request.POST['search']
        if search:
            match = Order.objects.filter(Q(cus_name__icontains =search) | Q(cus_ph__icontains =search) | Q(cloth_type__icontains =search) | Q(amount__icontains =search) | Q(order_date__icontains =search) | Q(deli_date__icontains =search) | Q(address__icontains =search))
            if match:
                    paginator = Paginator(match,3)
                    page_number = request.GET.get('page')
                    page_obj = paginator.get_page(page_number)
                    return render(request,'website/order_list.html',{'search1':match})
            else:
                messages.error(request,'No Result Found!!!')
        else:
            return HttpResponseRedirect('order_list')
        
    return render(request,'website/order_list.html')


def searchstock(request):
    
    if request.method== 'POST':
        search = request.POST['search']
        if search:
            
            match = Stock.objects.filter(Q(item__icontains =search) | Q(qty__icontains =search))
            if match:
                return render(request,'website/stock_list.html', {'search1':match})
            else:
                messages.error(request,'No Result Found!!!')
        else:
            return HttpResponseRedirect('stock_list')
        
    return render(request,'website/stock_list.html')

def searchitem(request):
    
    if request.method== 'POST':
        search = request.POST['search']
        if search:
            
            match = Cloth_Item.objects.filter(Q(item_name__icontains =search) | Q(price__icontains =search))
            if match:
                return render(request,'website/item_list.html', {'search1':match})
            else:
                messages.error(request,'No Result Found!!!')
        else:
            return HttpResponseRedirect('item_list')
        
    return render(request,'website/item_list.html')


def searchsale(request):
    
    if request.method== 'POST':
        search = request.POST['search']
        if search:
            
            match = Cloth_Item.objects.filter(Q(sale_item__icontains =search) | Q(sale_date__icontains =search) | Q(sale_qty__icontains =search) | Q(sale_price__icontains =search) | Q(sale_total__icontains =search) | Q(sale_remark__icontains =search))
            if match:
                return render(request,'website/sale_list.html', {'search1':match})
            else:
                messages.error(request,'No Result Found!!!')
        else:
            return HttpResponseRedirect('sale_list')
        
    return render(request,'website/sale_list.html')